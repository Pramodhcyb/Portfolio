import React from 'react';
import { Shield, Github, Linkedin, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-8">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <Shield className="h-6 w-6 text-primary-400" />
            <span className="font-bold text-lg text-white">Pramodh.Cyb</span>
          </div>
          
          <div className="flex items-center gap-4">
            <a 
              href="https://github.com/Pramodhcyb" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-white transition-colors duration-300"
              aria-label="GitHub"
            >
              <Github size={20} />
            </a>
            <a 
              href="https://www.linkedin.com/in/pramodh-prathap" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-400 hover:text-white transition-colors duration-300"
              aria-label="LinkedIn"
            >
              <Linkedin size={20} />
            </a>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {currentYear} Pramodh Prathap. All rights reserved.
          </p>
          
          <p className="text-gray-400 text-sm flex items-center gap-1">
            Crafted with 
            <Heart size={14} className="text-danger-500" fill="currentColor" /> 
            by Pramodh
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;