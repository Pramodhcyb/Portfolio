import React from 'react';
import { motion } from 'framer-motion';
import { sportsAchievements } from '../data';
import { Trophy, Medal, Calendar, ExternalLink } from 'lucide-react';

const Sports: React.FC = () => {
  return (
    <section id="sports" className="section-padding bg-gray-900">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="section-title">Sports Achievements</h2>
          <p className="text-gray-300 max-w-3xl">
            Beyond cybersecurity, I'm passionate about sports and have achieved recognition in various competitions.
          </p>
        </motion.div>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-0.5 bg-gray-800 transform -translate-x-1/2"></div>
          
          <div className="space-y-12">
            {sportsAchievements.map((achievement, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                className={`relative flex flex-col md:flex-row ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Timeline dot */}
                <div className="hidden md:block absolute left-1/2 top-0 w-4 h-4 rounded-full bg-primary-500 transform -translate-x-1/2"></div>
                
                <div className="md:w-1/2 md:px-8">
                  <div className="card p-6 h-full">
                    <div className="flex items-center gap-3 mb-4">
                      {index === 0 ? (
                        <Trophy size={24} className="text-yellow-500" />
                      ) : (
                        <Medal size={24} className="text-primary-400" />
                      )}
                      <h3 className="text-xl font-semibold text-white">{achievement.title}</h3>
                    </div>
                    
                    <div className="flex items-center gap-2 mb-3 text-gray-400">
                      <Calendar size={16} />
                      <span>{achievement.year}</span>
                    </div>
                    
                    <p className="text-gray-300 mb-4">{achievement.description}</p>
                    
                    <a 
                      href={achievement.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-outline text-sm inline-flex items-center gap-2"
                    >
                      <ExternalLink size={16} />
                      View Certificate
                    </a>
                  </div>
                </div>
                
                <div className="md:w-1/2"></div>
              </motion.div>
            ))}
          </div>
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 bg-gray-800 border border-gray-700 rounded-lg p-6"
        >
          <h3 className="heading-sm mb-4">How Sports Complements My Professional Skills</h3>
          
          <p className="text-gray-300 mb-6">
            My athletic background has instilled valuable traits that translate to my cybersecurity career:
            teamwork, discipline, strategic thinking, and performing under pressure.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-gray-900 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Teamwork</h4>
              <p className="text-gray-400 text-sm">Collaborating effectively with diverse teams toward common goals</p>
            </div>
            
            <div className="bg-gray-900 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Discipline</h4>
              <p className="text-gray-400 text-sm">Maintaining focus and dedication to continuous improvement</p>
            </div>
            
            <div className="bg-gray-900 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Strategic Thinking</h4>
              <p className="text-gray-400 text-sm">Analyzing situations and developing effective approaches</p>
            </div>
            
            <div className="bg-gray-900 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Resilience</h4>
              <p className="text-gray-400 text-sm">Overcoming challenges and adapting to changing circumstances</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Sports;