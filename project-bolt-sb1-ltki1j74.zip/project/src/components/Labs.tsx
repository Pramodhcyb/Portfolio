import React from 'react';
import { motion } from 'framer-motion';
import { labExperiences } from '../data';
import { Terminal, ExternalLink, Server, Award } from 'lucide-react';

const Labs: React.FC = () => {
  return (
    <section id="labs" className="section-padding bg-gray-950">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="section-title">Labs & Challenges</h2>
          <p className="text-gray-300 max-w-3xl">
            Hands-on experience through practical labs, CTF challenges, and security platforms
            that demonstrate my problem-solving abilities and technical expertise.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {labExperiences.map((lab, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="card h-full"
            >
              <div className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  {lab.platform === 'TryHackMe' ? (
                    <Terminal size={24} className="text-primary-400" />
                  ) : lab.platform === 'Hack The Box' ? (
                    <Server size={24} className="text-green-500" />
                  ) : (
                    <Award size={24} className="text-purple-500" />
                  )}
                  <h3 className="text-xl font-semibold text-white">{lab.platform}</h3>
                </div>
                
                <ul className="space-y-3 mb-6">
                  {lab.achievements.map((achievement, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="text-primary-400 mt-1">→</span>
                      <span className="text-gray-300">{achievement}</span>
                    </li>
                  ))}
                </ul>
                
                {lab.profileUrl !== '#' && (
                  <a 
                    href={lab.profileUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="btn-outline text-sm inline-flex items-center gap-2"
                  >
                    <ExternalLink size={16} />
                    View Profile
                  </a>
                )}
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
          className="mt-16 bg-gray-900 border border-gray-800 rounded-lg p-6"
        >
          <h3 className="heading-sm mb-4 flex items-center gap-2">
            <Terminal size={20} className="text-primary-400" />
            My Approach to Security Challenges
          </h3>
          
          <p className="text-gray-300 mb-4">
            My methodology for tackling security challenges focuses on understanding the underlying systems before 
            attempting to identify vulnerabilities. I believe in the value of both theoretical knowledge and 
            practical application, which is why I regularly participate in CTF competitions and maintain a personal lab 
            environment for testing and research.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
            <div className="bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Research & Enumeration</h4>
              <p className="text-gray-400 text-sm">Thorough information gathering and system mapping before action</p>
            </div>
            
            <div className="bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Methodical Testing</h4>
              <p className="text-gray-400 text-sm">Systematic approach to vulnerability assessment and exploitation</p>
            </div>
            
            <div className="bg-gray-800 p-4 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Documentation & Learning</h4>
              <p className="text-gray-400 text-sm">Detailed write-ups and continuous improvement from each challenge</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Labs;