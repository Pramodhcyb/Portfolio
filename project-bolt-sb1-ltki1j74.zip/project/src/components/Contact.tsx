import React from 'react';
import { motion } from 'framer-motion';
import { socialLinks } from '../data';
import { Mail, Send, Github, Linkedin, Shield } from 'lucide-react';

const Contact: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Github':
        return <Github size={20} />;
      case 'Linkedin':
        return <Linkedin size={20} />;
      case 'ShieldCheck':
        return <Shield size={20} />;
      default:
        return <Shield size={20} />;
    }
  };

  return (
    <section id="contact" className="section-padding bg-gray-950">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <h2 className="section-title">Let's Connect</h2>
          <p className="text-gray-300 max-w-3xl">
            I'm always open to discussing cybersecurity projects, opportunities, or just connecting with like-minded professionals.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="card p-6">
              <h3 className="heading-sm flex items-center gap-2 mb-6">
                <Mail className="text-primary-400" />
                Contact Me
              </h3>
              
              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-gray-300 mb-1">Your Name</label>
                  <input
                    type="text"
                    id="name"
                    placeholder="John Doe"
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-gray-300 mb-1">Your Email</label>
                  <input
                    type="email"
                    id="email"
                    placeholder="john@example.com"
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-gray-300 mb-1">Message</label>
                  <textarea
                    id="message"
                    rows={5}
                    placeholder="How can I help you?"
                    className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  ></textarea>
                </div>
                
                <button type="button" className="btn-primary w-full justify-center">
                  <Send size={18} />
                  Send Message
                </button>
              </form>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <div className="card p-6 h-full flex flex-col">
              <h3 className="heading-sm mb-6">Connect With Me</h3>
              
              <div className="space-y-6 flex-grow">
                <p className="text-gray-300">
                  Feel free to reach out on any of these platforms. I'm always interested in new connections and opportunities in the cybersecurity field.
                </p>
                
                <div className="space-y-4 mt-8">
                  {socialLinks.map((link, index) => (
                    <a
                      key={index}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors duration-300"
                    >
                      <div className="w-8 h-8 flex items-center justify-center bg-gray-700 rounded-md text-primary-400">
                        {getIcon(link.icon)}
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{link.platform}</h4>
                        <p className="text-sm text-gray-400">{link.url}</p>
                      </div>
                    </a>
                  ))}
                </div>
              </div>
              
              <div className="mt-8 pt-6 border-t border-gray-800">
                <h4 className="font-semibold text-white mb-2">Response Time</h4>
                <p className="text-gray-400">I typically respond within 24-48 hours.</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Contact;