import React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Github, Linkedin, ExternalLink } from 'lucide-react';
import { TypeAnimation } from 'react-type-animation';

const Hero: React.FC = () => {
  const scrollToProjects = () => {
    const projectsSection = document.getElementById('projects');
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0">
        <img 
          src="/images/WhatsApp Image 2025-06-01 at 11.44.51 AM.jpeg" 
          alt="Profile" 
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900/30 to-gray-900/80 dark:from-gray-950/40 dark:to-gray-950/90"></div>
      </div>
      
      <div className="container-custom relative z-10 h-screen flex flex-col justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >
          <h2 className="text-primary-400 font-mono mb-3">Hello, my name is</h2>
          <h1 className="heading-xl mb-4 text-white">PRAMODH</h1>
          
          <div className="heading-md text-gray-100 mb-6 h-16">
            <TypeAnimation
              sequence={[
                'Cybersecurity Specialist',
                2000,
                'Ethical Hacker',
                2000,
                'Security Engineer',
                2000,
              ]}
              wrapper="span"
              speed={50}
              repeat={Infinity}
              className="gradient-text"
            />
          </div>
          
          <p className="text-lg text-gray-200 max-w-2xl mb-8">
            Passionate about <span className="text-primary-400">offensive security</span> and <span className="text-secondary-500">threat intelligence</span>. 
            Dedicated to designing and implementing <span className="text-primary-400">robust security architectures</span> to protect digital assets.
          </p>
          
          <div className="flex flex-wrap gap-4">
            <button onClick={scrollToProjects} className="btn-primary">
              View My Projects
              <ExternalLink size={18} />
            </button>
            
            <a href="https://github.com/Pramodhcyb?tab=repositories" target="_blank" rel="noopener noreferrer" className="btn-outline">
              <Github size={18} />
              GitHub
            </a>
            
            <a href="https://www.linkedin.com/in/pramodh-prathap" target="_blank" rel="noopener noreferrer" className="btn-outline">
              <Linkedin size={18} />
              LinkedIn
            </a>
          </div>
        </motion.div>
      </div>
      
      <motion.div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 cursor-pointer"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 1.5 }}
        onClick={() => {
          const aboutSection = document.getElementById('about');
          if (aboutSection) {
            aboutSection.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      >
        <ChevronDown size={32} className="text-primary-400" />
      </motion.div>
    </section>
  );
};

export default Hero;