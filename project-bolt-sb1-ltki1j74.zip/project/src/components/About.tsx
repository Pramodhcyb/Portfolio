{/* Previous About.tsx content with updated education */}
import React from 'react';
import { motion } from 'framer-motion';
import { skills } from '../data';
import { ShieldCheck, Award, BookOpen } from 'lucide-react';

const About: React.FC = () => {
  const technicalSkills = skills.filter(skill => skill.category === 'technical');
  const certifications = skills.filter(skill => skill.category === 'certification');
  
  return (
    <section id="about" className="section-padding bg-gray-50 dark:bg-gray-900">
      <div className="container-custom">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2 className="section-title">About Me</h2>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <div className="prose prose-gray dark:prose-invert max-w-none">
              <p className="text-lg mb-4">
                Certified Ethical Hacker with a Master's in Computer Applications and hands-on experience in penetration testing, 
                vulnerability scanning, and threat detection. Skilled in tools like Nmap, Metasploit, Wireshark, and Burp Suite. 
                Passionate about automating security tasks using Python and building real-world cybersecurity labs.
              </p>
              
              <p className="text-lg mb-4">
                With a background in both offensive and defensive security, I bring a comprehensive approach to 
                identifying vulnerabilities and implementing robust security solutions. I believe in continuous learning 
                and staying ahead of emerging threats through practical experience and research.
              </p>
              
              <p className="text-lg mb-8">
                My goal is to contribute to building more secure digital environments through thoughtful security 
                architecture, effective penetration testing, and sharing knowledge with the community.
              </p>
            </div>
            
            <div className="mb-8">
              <h3 className="heading-sm flex items-center gap-2 mb-4">
                <ShieldCheck size={20} className="text-primary-400" />
                Technical Skills
              </h3>
              
              <div className="flex flex-wrap gap-2">
                {technicalSkills.map((skill, index) => (
                  <motion.span
                    key={index}
                    className="skill-item"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 * index }}
                    viewport={{ once: true }}
                  >
                    {skill.name}
                  </motion.span>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="heading-sm flex items-center gap-2 mb-4">
                <Award size={20} className="text-primary-400" />
                Certifications
              </h3>
              
              <div className="flex flex-wrap gap-2">
                {certifications.map((cert, index) => (
                  <motion.span
                    key={index}
                    className="skill-item"
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.1 * index }}
                    viewport={{ once: true }}
                  >
                    {cert.name}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            viewport={{ once: true }}
            className="lg:col-span-1"
          >
            <div className="card p-6">
              <h3 className="heading-sm flex items-center gap-2 mb-4">
                <BookOpen size={20} className="text-primary-400" />
                Education & Background
              </h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white">Master's in Computer Applications</h4>
                  <p className="text-gray-600 dark:text-gray-400">Specialized in Cybersecurity</p>
                  <p className="text-gray-500 dark:text-gray-500 text-sm">2023 - 2025</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-white">Bachelor's in Computer Science</h4>
                  <p className="text-gray-600 dark:text-gray-400">Focus on Computer Science & Security</p>
                  <p className="text-gray-500 dark:text-gray-500 text-sm">2019 - 2023</p>
                </div>
                
                <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Areas of Expertise</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-primary-400 mt-1">→</span>
                      <span>Network & Web Application Security</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary-400 mt-1">→</span>
                      <span>Security Automation & Tooling</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary-400 mt-1">→</span>
                      <span>Vulnerability Assessment</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-primary-400 mt-1">→</span>
                      <span>Incident Response & Forensics</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;