import { Skill, Project, LabExperience, SportsAchievement, SocialLink, NavItem } from '../types';
import { Github, Linkedin, Award, ShieldCheck } from 'lucide-react';

export const navItems: NavItem[] = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'projects', label: 'Projects' },
  { id: 'labs', label: 'Labs' },
  { id: 'sports', label: 'Sports' },
  { id: 'contact', label: 'Contact' },
];

export const skills: Skill[] = [
  { name: 'Penetration Testing', category: 'technical' },
  { name: 'Network Security', category: 'technical' },
  { name: 'Cloud Security', category: 'technical' },
  { name: 'Incident Response', category: 'technical' },
  { name: 'Forensics', category: 'technical' },
  { name: 'Python Scripting', category: 'technical' },
  { name: 'Linux Administration', category: 'technical' },
  { name: 'Web Application Security', category: 'technical' },
  { name: 'Vulnerability Assessment', category: 'technical' },
  { name: 'Threat Intelligence', category: 'technical' },
  { name: 'Firewall Configuration', category: 'technical' },
  { name: 'CompTIA Security+', category: 'certification' },
  { name: 'CEH', category: 'certification' },
  { name: 'CCNA', category: 'certification' },
];

export const projects: Project[] = [
  {
    id: 'miniwaf',
    title: 'MiniWAF: A Simple Web Application Firewall Rule Engine',
    description: 'A lightweight WAF solution designed to protect web applications from common attacks through customizable rule sets.',
    detailedDescription: 'MiniWAF is a lightweight Web Application Firewall implementation that provides protection against common web attacks including SQL injection, XSS, and CSRF. The engine uses a simple rule-based system that can be easily extended and customized for specific application needs. It includes a monitoring dashboard for real-time threat visibility and an API for integration with existing security infrastructure.',
    technologies: ['Python', 'Flask', 'RegEx', 'Docker', 'Nginx'],
    githubUrl: 'https://github.com/Pramodhcyb/MiniWAF',
    featured: true,
    imageUrl: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg'
  },
  {
    id: 'secuaudit',
    title: 'SecuAudit: Automated System Security Compliance Checker',
    description: 'An automated tool for auditing system security compliance against industry standards like CIS benchmarks.',
    detailedDescription: 'SecuAudit is a comprehensive security compliance checking tool that automatically audits systems against industry-standard benchmarks like CIS, NIST, and PCI-DSS. It generates detailed reports with remediation recommendations and can be scheduled to run periodically. The tool supports multiple platforms including Linux, Windows, and various cloud environments.',
    technologies: ['Python', 'Bash', 'PowerShell', 'AWS', 'Compliance Standards'],
    githubUrl: 'https://github.com/Pramodhcyb/SecuAudit',
    featured: true,
    imageUrl: 'https://images.pexels.com/photos/5380664/pexels-photo-5380664.jpeg'
  },
  {
    id: 'netscanner',
    title: 'NetScanner: Network Enumeration Tool',
    description: 'A lightweight network scanning and enumeration tool for security assessments.',
    technologies: ['Python', 'Scapy', 'Socket Programming'],
    githubUrl: 'https://github.com/Pramodhcyb/NetScanner',
    featured: false
  },
  {
    id: 'cryptolib',
    title: 'CryptoLib: Encryption Utilities',
    description: 'A library of encryption and hashing utilities for secure data handling.',
    technologies: ['Python', 'Cryptography', 'Hash Functions'],
    githubUrl: 'https://github.com/Pramodhcyb/CryptoLib',
    featured: false
  }
];

export const labExperiences: LabExperience[] = [
  {
    platform: 'TryHackMe',
    profileUrl: 'https://tryhackme.com/p/Pramodh.cyb',
    achievements: [
      'Completed Offensive Pentesting Learning Path',
      'Solved over 50 challenge rooms',
      'Top 5% on monthly leaderboard'
    ],
    logoUrl: 'https://assets.tryhackme.com/img/THMlogo.png'
  },
  {
    platform: 'Hack The Box',
    profileUrl: '#',
    achievements: [
      'Completed 25+ machines',
      'Participated in multiple CTF competitions',
      'Specialized in Windows Active Directory environments'
    ]
  },
  {
    platform: 'Personal Lab',
    profileUrl: '#',
    achievements: [
      'Built a comprehensive virtualized environment with 10+ machines',
      'Implemented IDS/IPS solutions',
      'Created attack and defense scenarios for practice'
    ]
  }
];

export const sportsAchievements: SportsAchievement[] = [
  {
    title: 'Baseball Nationals',
    year: '2024',
    description: 'Participated in the Baseball Nationals representing my region.',
    url: 'https://drive.google.com/file/d/1F5U_hdu92hwU-ig3Yt61FEgO8PbcXv9W/view?usp=drivesdk'
  },
  {
    title: 'Sports Achievement',
    year: '2024',
    description: 'Recognized for outstanding performance in collegiate sports events.',
    url: 'https://drive.google.com/file/d/1F5U_hdu92hwU-ig3Yt61FEgO8PbcXv9W/view?usp=drivesdk'
  },
  {
    title: 'Sports Achievement',
    year: '2023',
    description: 'Received honors for athletic excellence in university competitions.',
    url: 'https://drive.google.com/file/d/1F5U_hdu92hwU-ig3Yt61FEgO8PbcXv9W/view?usp=drivesdk'
  },
  {
    title: 'Sports Achievement',
    year: '2022',
    description: 'Awarded for exceptional performance in multiple sporting events.',
    url: 'https://drive.google.com/file/d/1F5U_hdu92hwU-ig3Yt61FEgO8PbcXv9W/view?usp=drivesdk'
  },
  {
    title: 'Championship Award',
    year: '2022',
    description: 'Received championship award at Reva University for outstanding sports contributions.',
    url: 'https://drive.google.com/file/d/1F5U_hdu92hwU-ig3Yt61FEgO8PbcXv9W/view?usp=drivesdk'
  }
];

export const socialLinks: SocialLink[] = [
  {
    platform: 'GitHub',
    url: 'https://github.com/Pramodhcyb',
    icon: 'Github'
  },
  {
    platform: 'LinkedIn',
    url: 'https://www.linkedin.com/in/pramodh-prathap',
    icon: 'Linkedin'
  },
  {
    platform: 'TryHackMe',
    url: 'https://tryhackme.com/p/Pramodh.cyb',
    icon: 'ShieldCheck'
  }
];