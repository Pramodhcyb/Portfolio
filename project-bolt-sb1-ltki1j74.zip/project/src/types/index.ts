export interface NavItem {
  id: string;
  label: string;
}

export interface Skill {
  name: string;
  category: 'technical' | 'soft' | 'certification';
}

export interface Project {
  id: string;
  title: string;
  description: string;
  technologies: string[];
  githubUrl: string;
  featured: boolean;
  imageUrl?: string;
  detailedDescription?: string;
}

export interface LabExperience {
  platform: string;
  profileUrl: string;
  achievements: string[];
  logoUrl?: string;
}

export interface SportsAchievement {
  title: string;
  year: string;
  description: string;
  url: string;
}

export interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}